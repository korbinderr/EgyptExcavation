#!/usr/bin/env bash
sudo certbot -n -d egyptexcavation.is404.net --nginx --agree-tos --email korbinderr@gmail.com
